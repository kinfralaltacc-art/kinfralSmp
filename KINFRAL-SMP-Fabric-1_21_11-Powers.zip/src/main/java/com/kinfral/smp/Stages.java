package com.kinfral.smp;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Stage progress is stored as command tags on the player (saved with the world,
 * kept across death). Tag format: kp_<power>_<stage>, selection: kpsel_<power>.
 */
public final class Stages {
    private Stages() {}

    // ---- Costs (edit these to rebalance) ----
    public static Item costItem(int stage) {
        return switch (stage) {
            case 1 -> Items.GOLD_BLOCK;
            case 2 -> Items.DIAMOND_BLOCK;
            default -> Items.NETHERITE_BLOCK;
        };
    }

    public static int costCount(int stage) {
        return switch (stage) {
            case 1 -> 2;
            case 2 -> 3;
            default -> 1;
        };
    }

    public static String costText(int stage) {
        return switch (stage) {
            case 1 -> "2 Blocks of Gold";
            case 2 -> "3 Blocks of Diamond";
            default -> "1 Block of Netherite";
        };
    }

    // ---- Stage storage ----
    public static int get(ServerPlayerEntity p, Power pw) {
        for (int s = 3; s >= 1; s--) {
            if (p.getCommandTags().contains("kp_" + pw.id + "_" + s)) return s;
        }
        return 0;
    }

    public static void set(ServerPlayerEntity p, Power pw, int stage) {
        for (int s = 1; s <= 3; s++) p.removeCommandTag("kp_" + pw.id + "_" + s);
        if (stage > 0) p.addCommandTag("kp_" + pw.id + "_" + stage);
    }

    public static Power selected(ServerPlayerEntity p) {
        for (Power pw : Power.values()) {
            if (p.getCommandTags().contains("kpsel_" + pw.id)) return pw;
        }
        return Power.values()[0];
    }

    public static void select(ServerPlayerEntity p, Power pw) {
        for (Power x : Power.values()) p.removeCommandTag("kpsel_" + x.id);
        p.addCommandTag("kpsel_" + pw.id);
    }

    // ---- Paying at the altar ----
    public static int count(ServerPlayerEntity p, Item item) {
        PlayerInventory inv = p.getInventory();
        int n = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    public static boolean canPay(ServerPlayerEntity p, int stage) {
        return count(p, costItem(stage)) >= costCount(stage);
    }

    public static void pay(ServerPlayerEntity p, int stage) {
        Item item = costItem(stage);
        int need = costCount(stage);
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size() && need > 0; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) {
                int take = Math.min(need, s.getCount());
                s.decrement(take);
                need -= take;
            }
        }
        inv.markDirty();
    }
}
