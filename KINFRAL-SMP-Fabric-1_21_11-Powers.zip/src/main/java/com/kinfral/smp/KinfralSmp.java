package com.kinfral.smp;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.mob.Monster;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.List;

/**
 * KINFRAL SMP - 15 powers, 3 stages each, unlocked at an altar by giving up
 * Gold / Diamond / Netherite blocks. PvE only.
 *
 * Commands (work without cheats):
 *   /altar                 summon an altar where you look
 *   /powers                list your powers and stages
 *   /powers wand           get the Power Wand
 *   /powers select <name>  choose which power the wand uses / the altar upgrades
 */
public class KinfralSmp implements ModInitializer {
    public static final String MOD_ID = "kinfral_smp";

    @Override
    public void onInitialize() {
        registerCommands();
        registerEvents();
    }

    // ---------------------------------------------------------------
    // Power Wand = a Blaze Rod with a hidden marker
    // ---------------------------------------------------------------
    private static ItemStack makeWand() {
        ItemStack s = new ItemStack(Items.BLAZE_ROD);
        NbtCompound tag = new NbtCompound();
        tag.putBoolean("kinfral_wand", true);
        s.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal("Power Wand").formatted(Formatting.GOLD));
        s.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        return s;
    }

    private static boolean isWand(ItemStack s) {
        if (!s.isOf(Items.BLAZE_ROD)) return false;
        NbtComponent c = s.get(DataComponentTypes.CUSTOM_DATA);
        return c != null && c.contains("kinfral_wand");
    }

    // ---------------------------------------------------------------
    // Commands
    // ---------------------------------------------------------------
    private static List<String> powerIds() {
        List<String> ids = new ArrayList<>();
        for (Power pw : Power.values()) ids.add(pw.id);
        return ids;
    }

    private static void listPowers(ServerPlayerEntity p) {
        Power sel = Stages.selected(p);
        StringBuilder sb = new StringBuilder("§6§l--- Your Powers ---§r\n");
        for (Power pw : Power.values()) {
            int st = Stages.get(p, pw);
            sb.append(pw == sel ? "§e> " : "§7  ")
                    .append(pw.display)
                    .append(" §f").append(st).append("/3 §8")
                    .append(pw.active ? "(wand)" : "(passive)")
                    .append('\n');
        }
        sb.append("§7/altar  |  /powers wand  |  /powers select <name>");
        p.sendMessage(Text.literal(sb.toString()), false);
    }

    private static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("altar").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                Altar.summon(p);
                return 1;
            }));

            dispatcher.register(CommandManager.literal("powers")
                    .executes(ctx -> {
                        listPowers(ctx.getSource().getPlayerOrThrow());
                        return 1;
                    })
                    .then(CommandManager.literal("wand").executes(ctx -> {
                        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                        ItemStack wand = makeWand();
                        if (!p.getInventory().insertStack(wand)) p.dropItem(wand, false);
                        p.sendMessage(Text.literal("§6[Powers] §fYou got the Power Wand. Right-click = use the selected power, sneak + right-click = switch power."), false);
                        return 1;
                    }))
                    .then(CommandManager.literal("select")
                            .then(CommandManager.argument("power", StringArgumentType.word())
                                    .suggests((ctx, builder) -> CommandSource.suggestMatching(powerIds(), builder))
                                    .executes(ctx -> {
                                        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                        Power pw = Power.byId(StringArgumentType.getString(ctx, "power"));
                                        if (pw == null) {
                                            p.sendMessage(Text.literal("§cUnknown power. Use /powers to see the list."), false);
                                            return 0;
                                        }
                                        Stages.select(p, pw);
                                        Altar.show(p, pw);
                                        return 1;
                                    }))));
        });
    }

    // ---------------------------------------------------------------
    // Events
    // ---------------------------------------------------------------
    private static void registerEvents() {
        // Altar: right-click the enchanting table that sits on crying obsidian
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            if (!Altar.isCore(world, hit.getBlockPos())) return ActionResult.PASS;
            return Altar.use(sp);
        });

        // Wand: right-click = use selected power, sneak + right-click = switch power
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            if (!isWand(sp.getStackInHand(hand))) return ActionResult.PASS;
            if (sp.isSneaking()) {
                Power n = Stages.selected(sp).next();
                Stages.select(sp, n);
                Altar.show(sp, n);
            } else {
                Abilities.activate(sp);
            }
            return ActionResult.SUCCESS;
        });

        // Kills (Soul Harvest / Soul Shield)
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.getAttacker() instanceof ServerPlayerEntity sp && entity instanceof Monster) {
                Abilities.onKill(sp, entity);
            }
        });

        // Vein Miner / Tree Feller
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world instanceof ServerWorld sw && player instanceof ServerPlayerEntity sp) {
                Abilities.onBlockBreak(sw, sp, pos, state);
            }
        });

        // Cooldowns + passive powers
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Abilities.tickCooldowns();
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                Abilities.tickPlayer(server, p);
            }
        });
    }
}
