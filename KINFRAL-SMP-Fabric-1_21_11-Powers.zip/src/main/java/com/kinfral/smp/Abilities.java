package com.kinfral.smp;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * All power behaviour. EVERYTHING here only targets hostile mobs (Monster) -
 * never players. See hostiles() and hit().
 */
public final class Abilities {
    private Abilities() {}

    // ---------------------------------------------------------------
    // Version-sensitive helpers. If a Minecraft/Yarn update renames
    // something, these are the places to patch.
    // ---------------------------------------------------------------
    public static ServerWorld w(ServerPlayerEntity p) {
        return (ServerWorld) p.getEntityWorld();
    }

    static Vec3d pos(Entity e) {
        return new Vec3d(e.getX(), e.getY(), e.getZ());
    }

    // ---------------------------------------------------------------
    // State (in memory; cooldowns reset when the game restarts)
    // ---------------------------------------------------------------
    private static final Map<String, Integer> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Integer> SLAM_AIR = new HashMap<>();
    private static final Map<UUID, Integer> SOULS = new HashMap<>();
    private static final Map<UUID, Float> PREV_ABS = new HashMap<>();

    private static String key(ServerPlayerEntity p, String id) {
        return p.getUuid() + ":" + id;
    }

    private static int cdLeft(ServerPlayerEntity p, String id) {
        return COOLDOWNS.getOrDefault(key(p, id), 0);
    }

    private static void setCd(ServerPlayerEntity p, String id, int ticks) {
        if (ticks > 0) COOLDOWNS.put(key(p, id), ticks);
    }

    public static void tickCooldowns() {
        Iterator<Map.Entry<String, Integer>> it = COOLDOWNS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Integer> e = it.next();
            int v = e.getValue() - 1;
            if (v <= 0) it.remove();
            else e.setValue(v);
        }
    }

    // ---------------------------------------------------------------
    // Small helpers
    // ---------------------------------------------------------------
    static void bar(ServerPlayerEntity p, String msg) {
        p.sendMessage(Text.literal(msg), true);
    }

    static void fx(LivingEntity e, RegistryEntry<StatusEffect> eff, int ticks, int amp) {
        e.addStatusEffect(new StatusEffectInstance(eff, ticks, amp));
    }

    static void push(Entity e, Vec3d v) {
        e.setVelocity(v);
        e.velocityModified = true;
    }

    static void puff(ServerWorld w, ParticleEffect type, Vec3d at, int n, double spread, double speed) {
        w.spawnParticles(type, at.x, at.y, at.z, n, spread, spread, spread, speed);
    }

    /** PvE ONLY: the only things powers can target are hostile mobs. */
    static List<MobEntity> hostiles(ServerPlayerEntity p, Vec3d center, double r) {
        Box box = new Box(center.x - r, center.y - r, center.z - r, center.x + r, center.y + r, center.z + r);
        List<MobEntity> out = new ArrayList<>();
        for (MobEntity m : w(p).getEntitiesByClass(MobEntity.class, box, e -> e instanceof Monster && e.isAlive())) {
            if (m.squaredDistanceTo(center) <= r * r) out.add(m);
        }
        return out;
    }

    static void hit(ServerPlayerEntity p, LivingEntity target, float dmg) {
        ServerWorld w = w(p);
        target.damage(w, w.getDamageSources().playerAttack(p), dmg);
    }

    /** Hostile mob closest to the crosshair, or null. */
    static MobEntity lookTarget(ServerPlayerEntity p, double range) {
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0F);
        MobEntity best = null;
        double bestDot = 0.93;
        for (MobEntity m : hostiles(p, pos(p), range)) {
            Vec3d to = m.getBoundingBox().getCenter().subtract(eye);
            if (to.length() < 0.5) continue;
            double dot = to.normalize().dotProduct(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = m;
            }
        }
        return best;
    }

    private static BlockHitResult rayBlock(ServerPlayerEntity p, double range) {
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0F);
        return w(p).raycast(new RaycastContext(eye, eye.add(look.multiply(range)),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
    }

    // ---------------------------------------------------------------
    // Wand activation (active powers)
    // ---------------------------------------------------------------
    public static void activate(ServerPlayerEntity p) {
        Power pw = Stages.selected(p);
        int st = Stages.get(p, pw);
        if (st == 0) {
            bar(p, "§c" + pw.display + " is locked - unlock it at an altar");
            return;
        }
        if (!pw.active) {
            bar(p, "§7" + pw.display + " is passive - it is always on");
            return;
        }
        int left = cdLeft(p, pw.id);
        if (left > 0) {
            bar(p, "§c" + pw.display + " cooldown: " + (left / 20 + 1) + "s");
            return;
        }
        boolean ok = switch (pw) {
            case SHADOW_STEP -> shadowStep(p, st);
            case LIGHTNING_STRIKE -> lightning(p, st);
            case GRAPPLE_HOOK -> grapple(p, st);
            case PHASE_DASH -> phaseDash(p, st);
            case EARTH_BENDER -> earthBender(p, st);
            case ICE_NOVA -> iceNova(p, st);
            case GRAVITY_SLAM -> gravitySlam(p);
            case MOB_FREEZE -> mobFreeze(p, st);
            case BEAST_SUMMON -> beastSummon(p, st);
            default -> false;
        };
        if (ok) {
            setCd(p, pw.id, pw.cooldownTicks(st));
            bar(p, "§6" + pw.display + " §7(stage " + st + ")");
        }
    }

    // ---- 1. Shadow Step ----
    private static boolean shadowStep(ServerPlayerEntity p, int st) {
        ServerWorld w = w(p);
        double dist = st == 1 ? 8 : st == 2 ? 12 : 16;
        Vec3d start = pos(p);
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d dir = new Vec3d(look.x, 0, look.z);
        if (dir.lengthSquared() < 1.0E-4) {
            bar(p, "§cLook forward to step");
            return false;
        }
        dir = dir.normalize();

        if (st == 3) {
            for (MobEntity m : hostiles(p, start, 10)) m.setTarget(null);
        }

        boolean moved = false;
        for (double d = dist; d >= 2 && !moved; d -= 1) {
            for (int dy = 0; dy <= 2 && !moved; dy++) {
                moved = p.teleport(start.x + dir.x * d, start.y + dy, start.z + dir.z * d, true);
            }
        }
        if (!moved) {
            bar(p, "§cNo room to step");
            return false;
        }
        puff(w, ParticleTypes.PORTAL, start.add(0, 1, 0), 40, 0.4, 0.2);
        puff(w, ParticleTypes.PORTAL, pos(p).add(0, 1, 0), 40, 0.4, 0.2);
        if (st == 2) fx(p, StatusEffects.INVISIBILITY, 80, 0);
        if (st == 3) fx(p, StatusEffects.INVISIBILITY, 160, 0);
        return true;
    }

    // ---- 4. Lightning Strike ----
    private static void strike(ServerPlayerEntity p, LivingEntity t, float dmg) {
        ServerWorld w = w(p);
        LightningEntity bolt = new LightningEntity(EntityType.LIGHTNING_BOLT, w);
        bolt.setPosition(t.getX(), t.getY(), t.getZ());
        bolt.setCosmetic(true);
        w.spawnEntity(bolt);
        hit(p, t, dmg);
    }

    private static boolean lightning(ServerPlayerEntity p, int st) {
        if (st == 3) {
            List<MobEntity> list = hostiles(p, pos(p), 16);
            if (list.isEmpty()) {
                bar(p, "§cNo hostile mobs nearby");
                return false;
            }
            int n = 0;
            for (MobEntity m : list) {
                if (n++ >= 8) break;
                strike(p, m, 12f);
            }
            return true;
        }

        MobEntity first = lookTarget(p, 24);
        if (first == null) {
            bar(p, "§cNo hostile mob in your sights");
            return false;
        }
        strike(p, first, 10f);
        if (st == 2) {
            List<MobEntity> hitList = new ArrayList<>();
            hitList.add(first);
            MobEntity cur = first;
            for (int i = 0; i < 4; i++) {
                MobEntity nxt = null;
                double bd = 36;
                for (MobEntity m : hostiles(p, pos(cur), 6)) {
                    if (hitList.contains(m)) continue;
                    double d = m.squaredDistanceTo(cur);
                    if (d < bd) {
                        bd = d;
                        nxt = m;
                    }
                }
                if (nxt == null) break;
                strike(p, nxt, 8f);
                hitList.add(nxt);
                cur = nxt;
            }
        }
        return true;
    }

    // ---- 5. Grapple Hook ----
    private static boolean grapple(ServerPlayerEntity p, int st) {
        if (st == 3) {
            MobEntity m = lookTarget(p, 24);
            if (m != null) {
                Vec3d toMe = pos(p).subtract(pos(m));
                push(m, toMe.normalize().multiply(1.6).add(0, 0.35, 0));
                puff(w(p), ParticleTypes.CRIT, pos(m).add(0, 1, 0), 20, 0.4, 0.1);
                return true;
            }
        }
        double range = st == 1 ? 20 : 40;
        BlockHitResult hit = rayBlock(p, range);
        if (hit.getType() != HitResult.Type.BLOCK) {
            bar(p, "§cNothing to grapple to");
            return false;
        }
        Vec3d to = hit.getPos().subtract(p.getEyePos());
        double len = to.length();
        Vec3d v = to.normalize().multiply(Math.min(2.4, 0.6 + len * 0.08));
        push(p, v.add(0, 0.3, 0));
        p.fallDistance = 0;
        puff(w(p), ParticleTypes.CRIT, hit.getPos(), 15, 0.2, 0.05);
        return true;
    }

    // ---- 6. Phase Dash ----
    private static boolean phaseDash(ServerPlayerEntity p, int st) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d dir = new Vec3d(look.x, 0, look.z);
        if (dir.lengthSquared() < 1.0E-4) {
            bar(p, "§cLook forward to dash");
            return false;
        }
        dir = dir.normalize();
        double speed = st == 1 ? 1.9 : st == 2 ? 2.4 : 3.0;
        Vec3d start = pos(p);
        if (st >= 2) {
            for (MobEntity m : hostiles(p, start, 9)) {
                Vec3d to = pos(m).subtract(start);
                double along = to.dotProduct(dir);
                double lat = to.subtract(dir.multiply(along)).length();
                if (along >= 0 && along <= 8 && lat <= 2.2) hit(p, m, st == 2 ? 6f : 10f);
            }
        }
        if (st == 3) fx(p, StatusEffects.RESISTANCE, 40, 4);
        push(p, new Vec3d(dir.x * speed, 0.15, dir.z * speed));
        p.fallDistance = 0;
        puff(w(p), ParticleTypes.CLOUD, start.add(0, 1, 0), 25, 0.3, 0.05);
        return true;
    }

    // ---- 9. Earth Bender ----
    private static void place(ServerWorld w, BlockPos b) {
        if (w.getBlockState(b).isAir()) {
            w.setBlockState(b, Blocks.STONE.getDefaultState(), Block.NOTIFY_ALL);
        }
    }

    private static boolean earthBender(ServerPlayerEntity p, int st) {
        ServerWorld w = w(p);
        BlockHitResult hit = rayBlock(p, 24);
        if (hit.getType() != HitResult.Type.BLOCK) {
            bar(p, "§cLook at the ground or a wall");
            return false;
        }
        BlockPos base = hit.getBlockPos().offset(hit.getSide());
        if (base.getSquaredDistance(p.getBlockPos()) < 16) {
            bar(p, "§cToo close - aim further away");
            return false;
        }

        if (st == 1) {
            for (int h = 0; h < 4; h++) place(w, base.up(h));
        } else {
            Vec3d look = p.getRotationVec(1.0F);
            double px = -look.z;
            double pz = look.x;
            double len = Math.hypot(px, pz);
            if (len < 1.0E-4) {
                px = 1;
                pz = 0;
                len = 1;
            }
            px /= len;
            pz /= len;
            for (int i = -2; i <= 2; i++) {
                for (int h = 0; h < 3; h++) {
                    place(w, base.add((int) Math.round(px * i), h, (int) Math.round(pz * i)));
                }
            }
        }
        if (st == 3) {
            Vec3d c = Vec3d.ofCenter(base);
            for (MobEntity m : hostiles(p, c, 7)) {
                hit(p, m, 8f);
                push(m, new Vec3d(0, 0.9, 0));
            }
            puff(w, ParticleTypes.CLOUD, c, 40, 1.5, 0.1);
        }
        return true;
    }

    // ---- 10. Ice Nova ----
    private static void freezeFluids(ServerWorld w, BlockPos c, int r) {
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (dx * dx + dz * dz > r * r) continue;
                for (int dy = -3; dy <= 3; dy++) {
                    BlockPos b = c.add(dx, dy, dz);
                    if (b.getSquaredDistance(c) < 5) continue; // never freeze the player in place
                    BlockState s = w.getBlockState(b);
                    if (s.isOf(Blocks.WATER) && s.getFluidState().isStill()) {
                        w.setBlockState(b, Blocks.ICE.getDefaultState(), Block.NOTIFY_ALL);
                    } else if (s.isOf(Blocks.LAVA) && s.getFluidState().isStill()) {
                        w.setBlockState(b, Blocks.OBSIDIAN.getDefaultState(), Block.NOTIFY_ALL);
                    }
                }
            }
        }
    }

    private static boolean iceNova(ServerPlayerEntity p, int st) {
        double r = st == 1 ? 6 : st == 2 ? 8 : 10;
        List<MobEntity> list = hostiles(p, pos(p), r);
        if (list.isEmpty() && st == 1) {
            bar(p, "§cNo hostile mobs nearby");
            return false;
        }
        for (MobEntity m : list) {
            fx(m, StatusEffects.SLOWNESS, 100, 6);
            fx(m, StatusEffects.WEAKNESS, 100, 4);
            if (st == 3) hit(p, m, 10f);
        }
        if (st >= 2) freezeFluids(w(p), p.getBlockPos(), (int) r);
        puff(w(p), ParticleTypes.SNOWFLAKE, pos(p).add(0, 1, 0), 120, r / 2, 0.05);
        return true;
    }

    // ---- 12. Gravity Slam ----
    private static boolean gravitySlam(ServerPlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0F);
        push(p, new Vec3d(look.x * 0.5, 1.1, look.z * 0.5));
        SLAM_AIR.put(p.getUuid(), 0);
        return true;
    }

    private static void slamLand(ServerPlayerEntity p) {
        int st = Math.max(1, Stages.get(p, Power.GRAVITY_SLAM));
        double r = st == 1 ? 4 : st == 2 ? 7 : 10;
        float dmg = st == 1 ? 8f : st == 2 ? 12f : 16f;
        Vec3d c = pos(p);
        for (MobEntity m : hostiles(p, c, r)) {
            hit(p, m, dmg);
            Vec3d away = pos(m).subtract(c);
            away = new Vec3d(away.x, 0, away.z);
            if (away.lengthSquared() > 1.0E-4) away = away.normalize().multiply(1.1);
            push(m, away.add(0, 0.5, 0));
            if (st == 3) fx(m, StatusEffects.SLOWNESS, 60, 3);
        }
        puff(w(p), ParticleTypes.EXPLOSION, c, 3, 0.5, 0.0);
        puff(w(p), ParticleTypes.CLOUD, c.add(0, 0.2, 0), 60, r / 3, 0.15);
    }

    private static void tickSlam(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        if (!SLAM_AIR.containsKey(id)) return;
        int air = SLAM_AIR.merge(id, 1, Integer::sum);
        p.fallDistance = 0; // slam never hurts you
        if (air == 12) push(p, new Vec3d(0, -1.8, 0));
        if (air > 200) {
            SLAM_AIR.remove(id);
        } else if (air >= 6 && p.isOnGround()) {
            SLAM_AIR.remove(id);
            slamLand(p);
        }
    }

    // ---- 14. Mob Freeze ----
    private static boolean mobFreeze(ServerPlayerEntity p, int st) {
        double r = st == 1 ? 10 : st == 2 ? 14 : 20;
        List<MobEntity> list = hostiles(p, pos(p), r);
        if (list.isEmpty()) {
            bar(p, "§cNo hostile mobs nearby");
            return false;
        }
        for (MobEntity m : list) {
            if (st == 1) {
                fx(m, StatusEffects.SLOWNESS, 160, 2);
            } else if (st == 2) {
                fx(m, StatusEffects.SLOWNESS, 160, 4);
                fx(m, StatusEffects.WEAKNESS, 160, 2);
            } else {
                fx(m, StatusEffects.SLOWNESS, 60, 6);
                fx(m, StatusEffects.WEAKNESS, 60, 9);
            }
            puff(w(p), ParticleTypes.SNOWFLAKE, pos(m).add(0, 1, 0), 15, 0.4, 0.02);
        }
        return true;
    }

    // ---- 15. Beast Summon ----
    private static boolean beastSummon(ServerPlayerEntity p, int st) {
        ServerWorld w = w(p);
        String tag = "kp_beast_" + p.getUuid().toString().substring(0, 8);

        // remove the previous summons so they never pile up
        Box big = new Box(p.getX() - 128, p.getY() - 128, p.getZ() - 128, p.getX() + 128, p.getY() + 128, p.getZ() + 128);
        for (MobEntity old : w.getEntitiesByClass(MobEntity.class, big, e -> e.getCommandTags().contains(tag))) {
            old.discard();
        }

        int wolves = st == 1 ? 1 : 3;
        for (int i = 0; i < wolves; i++) {
            WolfEntity wolf = new WolfEntity(EntityType.WOLF, w);
            wolf.setPosition(p.getX() + (i - 1) * 1.2, p.getY(), p.getZ() + 1.5);
            wolf.setTamedBy(p);
            wolf.addCommandTag(tag);
            w.spawnEntity(wolf);
        }
        if (st == 3) {
            IronGolemEntity golem = new IronGolemEntity(EntityType.IRON_GOLEM, w);
            golem.setPosition(p.getX() - 2.5, p.getY(), p.getZ() - 1.5);
            golem.setPlayerCreated(true);
            EntityAttributeInstance hp = golem.getAttributeInstance(EntityAttributes.MAX_HEALTH);
            if (hp != null) hp.setBaseValue(150.0);
            golem.setHealth(150.0F);
            golem.addCommandTag(tag);
            w.spawnEntity(golem);
        }
        puff(w, ParticleTypes.SOUL, pos(p).add(0, 1, 0), 40, 1.2, 0.05);
        return true;
    }

    // ---------------------------------------------------------------
    // Passive powers
    // ---------------------------------------------------------------
    public static void tickPlayer(MinecraftServer server, ServerPlayerEntity p) {
        tickSlam(p);
        tickSoulShield(p);
        int t = server.getTicks();
        if (t % 10 == 0) {
            bloodRage(p);
            flameAura(p, t);
        }
    }

    // ---- 3. Blood Rage ----
    private static void bloodRage(ServerPlayerEntity p) {
        int st = Stages.get(p, Power.BLOOD_RAGE);
        if (st == 0) return;
        if (p.getHealth() / p.getMaxHealth() <= 0.5f) {
            fx(p, StatusEffects.STRENGTH, 40, st == 1 ? 0 : 1);
            if (st >= 2) fx(p, StatusEffects.SPEED, 40, 0);
        }
        if (st == 3 && p.getHealth() <= 2.0f && cdLeft(p, "blood_rage_save") == 0) {
            fx(p, StatusEffects.RESISTANCE, 60, 4);
            setCd(p, "blood_rage_save", 20 * 60);
            bar(p, "§4Blood Rage: last stand!");
        }
    }

    // ---- 11. Flame Aura ----
    private static void flameAura(ServerPlayerEntity p, int t) {
        int st = Stages.get(p, Power.FLAME_AURA);
        if (st == 0) return;
        double r = st == 1 ? 3 : st == 2 ? 5 : 7;
        puff(w(p), ParticleTypes.FLAME, pos(p).add(0, 0.3, 0), 10, r / 2.5, 0.01);
        if (st == 3) fx(p, StatusEffects.FIRE_RESISTANCE, 60, 0);
        for (MobEntity m : hostiles(p, pos(p), r)) {
            m.setOnFireFor(4);
            if (st >= 2 && t % 20 == 0) hit(p, m, st == 2 ? 1.5f : 3f);
        }
    }

    // ---- 13. Soul Shield (shield break burst) ----
    private static void tickSoulShield(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        if (Stages.get(p, Power.SOUL_SHIELD) == 3) {
            float abs = p.getAbsorptionAmount();
            Float prev = PREV_ABS.put(id, abs);
            if (prev != null && prev > 0 && abs <= 0) shieldBurst(p);
        } else {
            PREV_ABS.remove(id);
        }
    }

    private static void shieldBurst(ServerPlayerEntity p) {
        Vec3d c = pos(p);
        for (MobEntity m : hostiles(p, c, 6)) {
            hit(p, m, 10f);
            Vec3d away = pos(m).subtract(c);
            away = new Vec3d(away.x, 0, away.z);
            if (away.lengthSquared() > 1.0E-4) away = away.normalize().multiply(1.2);
            push(m, away.add(0, 0.4, 0));
        }
        puff(w(p), ParticleTypes.SOUL, c.add(0, 1, 0), 60, 1.5, 0.1);
        bar(p, "§5Soul Shield shattered!");
    }

    // ---- 2 + 13. Kills: Soul Harvest and Soul Shield ----
    public static void onKill(ServerPlayerEntity p, LivingEntity victim) {
        int sh = Stages.get(p, Power.SOUL_HARVEST);
        if (sh > 0) {
            p.addExperience(3);
            int souls = SOULS.merge(p.getUuid(), 1, Integer::sum);
            if (sh >= 2) p.heal(2.0f);
            if (sh == 3 && souls >= 5) {
                SOULS.put(p.getUuid(), souls - 5);
                for (MobEntity m : hostiles(p, pos(p), 14)) {
                    hit(p, m, 10f);
                    puff(w(p), ParticleTypes.SOUL, pos(m).add(0, 1, 0), 15, 0.4, 0.05);
                }
                bar(p, "§5Soul blast!");
            } else {
                bar(p, "§5Souls: " + SOULS.getOrDefault(p.getUuid(), 0));
            }
        }
        int ss = Stages.get(p, Power.SOUL_SHIELD);
        if (ss > 0) {
            float cap = ss == 1 ? 4f : ss == 2 ? 12f : 20f;
            float add = ss == 1 ? 2f : 4f;
            p.setAbsorptionAmount(Math.min(cap, p.getAbsorptionAmount() + add));
        }
    }

    // ---------------------------------------------------------------
    // Block breaking: Vein Miner + Tree Feller
    // (sneak while breaking to mine normally)
    // ---------------------------------------------------------------
    private static final List<TagKey<Block>> ORE_TAGS = List.of(
            BlockTags.COAL_ORES, BlockTags.IRON_ORES, BlockTags.COPPER_ORES, BlockTags.GOLD_ORES,
            BlockTags.REDSTONE_ORES, BlockTags.LAPIS_ORES, BlockTags.DIAMOND_ORES, BlockTags.EMERALD_ORES);

    private static TagKey<Block> oreTag(BlockState s) {
        for (TagKey<Block> t : ORE_TAGS) {
            if (s.isIn(t)) return t;
        }
        return null;
    }

    private static void breakBlock(ServerWorld w, ServerPlayerEntity p, BlockPos pos, BlockState s, ItemStack tool) {
        Block.dropStacks(s, w, pos, w.getBlockEntity(pos), p, tool);
        w.removeBlock(pos, false);
    }

    public static void onBlockBreak(ServerWorld w, ServerPlayerEntity p, BlockPos pos, BlockState state) {
        if (p.isSneaking() || p.isCreative()) return;
        ItemStack tool = p.getMainHandStack();

        int vm = Stages.get(p, Power.VEIN_MINER);
        TagKey<Block> ore = oreTag(state);
        if (vm > 0 && ore != null && tool.isSuitableFor(state)) {
            veinMine(w, p, pos, ore, vm, tool);
            return;
        }

        int tf = Stages.get(p, Power.TREE_FELLER);
        if (tf > 0 && state.isIn(BlockTags.LOGS) && tool.isIn(ItemTags.AXES)) {
            fell(w, p, pos, state, tf, tool);
        }
    }

    private static void veinMine(ServerWorld w, ServerPlayerEntity p, BlockPos start, TagKey<Block> ore, int st, ItemStack tool) {
        int limit = st == 1 ? 8 : st == 2 ? 24 : 48;
        ArrayDeque<BlockPos> q = new ArrayDeque<>();
        Set<BlockPos> seen = new HashSet<>();
        q.add(start);
        seen.add(start);
        int broken = 0;
        while (!q.isEmpty() && broken < limit) {
            BlockPos c = q.poll();
            for (int dx = -1; dx <= 1 && broken < limit; dx++) {
                for (int dy = -1; dy <= 1 && broken < limit; dy++) {
                    for (int dz = -1; dz <= 1 && broken < limit; dz++) {
                        BlockPos n = c.add(dx, dy, dz);
                        if (!seen.add(n)) continue;
                        BlockState ns = w.getBlockState(n);
                        if (ns.isIn(ore)) {
                            q.add(n);
                            breakBlock(w, p, n, ns, tool);
                            broken++;
                        }
                    }
                }
            }
        }
        if (st == 3 && broken > 0) p.addExperience(broken);
    }

    private static Block sapling(BlockState s) {
        if (s.isOf(Blocks.OAK_LOG)) return Blocks.OAK_SAPLING;
        if (s.isOf(Blocks.BIRCH_LOG)) return Blocks.BIRCH_SAPLING;
        if (s.isOf(Blocks.SPRUCE_LOG)) return Blocks.SPRUCE_SAPLING;
        if (s.isOf(Blocks.JUNGLE_LOG)) return Blocks.JUNGLE_SAPLING;
        if (s.isOf(Blocks.ACACIA_LOG)) return Blocks.ACACIA_SAPLING;
        if (s.isOf(Blocks.DARK_OAK_LOG)) return Blocks.DARK_OAK_SAPLING;
        if (s.isOf(Blocks.CHERRY_LOG)) return Blocks.CHERRY_SAPLING;
        if (s.isOf(Blocks.MANGROVE_LOG)) return Blocks.MANGROVE_PROPAGULE;
        return null;
    }

    private static void fell(ServerWorld w, ServerPlayerEntity p, BlockPos start, BlockState startState, int st, ItemStack tool) {
        // 1) find connected logs
        Set<BlockPos> logs = new LinkedHashSet<>();
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> q = new ArrayDeque<>();
        q.add(start);
        seen.add(start);
        while (!q.isEmpty() && logs.size() < 150) {
            BlockPos c = q.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos n = c.add(dx, dy, dz);
                        if (!seen.add(n)) continue;
                        if (w.getBlockState(n).isIn(BlockTags.LOGS)) {
                            logs.add(n);
                            q.add(n);
                        }
                    }
                }
            }
        }
        // 2) natural leaves near the logs (player-placed leaves are persistent and ignored)
        Set<BlockPos> leaves = new LinkedHashSet<>();
        List<BlockPos> around = new ArrayList<>(logs);
        around.add(start);
        for (BlockPos l : around) {
            for (int dx = -3; dx <= 3; dx++) {
                for (int dy = -3; dy <= 3; dy++) {
                    for (int dz = -3; dz <= 3; dz++) {
                        BlockPos n = l.add(dx, dy, dz);
                        if (leaves.contains(n)) continue;
                        BlockState ls = w.getBlockState(n);
                        if (ls.isIn(BlockTags.LEAVES) && !ls.get(LeavesBlock.PERSISTENT)) leaves.add(n);
                    }
                }
            }
        }
        if (leaves.isEmpty()) return; // no natural leaves = not a tree (protects log builds)

        BlockPos lowest = start;
        for (BlockPos l : logs) {
            if (l.getY() < lowest.getY()) lowest = l;
        }
        for (BlockPos l : logs) {
            breakBlock(w, p, l, w.getBlockState(l), tool);
        }
        if (st >= 2) {
            for (BlockPos l : leaves) {
                BlockState ls = w.getBlockState(l);
                if (ls.isIn(BlockTags.LEAVES)) breakBlock(w, p, l, ls, tool);
            }
        }
        if (st == 3) {
            Block sap = sapling(startState);
            if (sap != null && w.getBlockState(lowest).isAir() && w.getBlockState(lowest.down()).isIn(BlockTags.DIRT)) {
                w.setBlockState(lowest, sap.getDefaultState(), Block.NOTIFY_ALL);
            }
        }
    }
}
