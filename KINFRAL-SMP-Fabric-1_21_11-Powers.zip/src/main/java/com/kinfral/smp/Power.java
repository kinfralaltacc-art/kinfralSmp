package com.kinfral.smp;

/**
 * The 15 powers. Each has 3 stages. Active powers are used with the Power Wand,
 * passive powers are always on once stage 1 is unlocked.
 * Cooldowns are in seconds (stage 1, 2, 3).
 */
public enum Power {
    SHADOW_STEP("shadow_step", "Shadow Step", true, 8, 7, 6,
            "Teleport 8 blocks forward",
            "Teleport 12 blocks + brief invisibility",
            "Teleport 16 blocks, invisible, nearby mobs lose track of you"),
    SOUL_HARVEST("soul_harvest", "Soul Harvest", false, 0, 0, 0,
            "Kills give bonus XP and collect souls",
            "Each kill also heals you",
            "Every 5 souls fire a blast at nearby mobs"),
    BLOOD_RAGE("blood_rage", "Blood Rage", false, 0, 0, 0,
            "Strength when below half health",
            "Strength II + Speed when below half health",
            "Also brief invincibility at 1 heart (60s cooldown)"),
    LIGHTNING_STRIKE("lightning_strike", "Lightning Strike", true, 10, 9, 12,
            "Call a bolt on the mob you look at",
            "The bolt chains to 4 more mobs",
            "Storm: bolts hit up to 8 mobs around you"),
    GRAPPLE_HOOK("grapple_hook", "Grapple Hook", true, 4, 3, 3,
            "Grapple to a block up to 20 blocks away",
            "Grapple up to 40 blocks away",
            "40 blocks, and pulls the mob you look at to you"),
    PHASE_DASH("phase_dash", "Phase Dash", true, 6, 6, 7,
            "Fast dash forward",
            "Dash that damages mobs in your path",
            "Longer dash, damages mobs, brief invincibility"),
    VEIN_MINER("vein_miner", "Vein Miner", false, 0, 0, 0,
            "Mining an ore breaks the vein (up to 8 blocks)",
            "Bigger veins (up to 24 blocks)",
            "Huge veins (up to 48 blocks) + bonus XP"),
    TREE_FELLER("tree_feller", "Tree Feller", false, 0, 0, 0,
            "Chopping a tree with an axe fells the whole tree",
            "Leaves vanish too",
            "Auto-replants the sapling"),
    EARTH_BENDER("earth_bender", "Earth Bender", true, 8, 8, 10,
            "Raise a stone pillar where you look",
            "Raise a stone wall where you look",
            "Wall + shockwave that launches mobs"),
    ICE_NOVA("ice_nova", "Ice Nova", true, 12, 12, 14,
            "Freeze nearby mobs in place",
            "Also freezes nearby water and lava",
            "Shatter: frozen mobs take big damage"),
    FLAME_AURA("flame_aura", "Flame Aura", false, 0, 0, 0,
            "Ring of fire ignites mobs near you",
            "Bigger ring that also burns them",
            "Biggest ring, more damage, fire immunity"),
    GRAVITY_SLAM("gravity_slam", "Gravity Slam", true, 10, 9, 8,
            "Leap and slam: small shockwave",
            "Bigger shockwave",
            "Huge shockwave that stuns mobs"),
    SOUL_SHIELD("soul_shield", "Soul Shield", false, 0, 0, 0,
            "Kills give absorption hearts",
            "Bigger shield per kill",
            "Shield blasts nearby mobs when it breaks"),
    MOB_FREEZE("mob_freeze", "Mob Freeze", true, 20, 18, 25,
            "Slow nearby hostile mobs",
            "Slow and weaken them",
            "Freeze every hostile mob around you for 3 seconds"),
    BEAST_SUMMON("beast_summon", "Beast Summon", true, 30, 30, 45,
            "Summon a tamed wolf",
            "Summon a pack of 3 wolves",
            "Wolf pack + an Iron Golem guardian");

    public final String id;
    public final String display;
    public final boolean active;
    private final int[] cooldowns;
    private final String[] text;

    Power(String id, String display, boolean active, int c1, int c2, int c3,
          String t1, String t2, String t3) {
        this.id = id;
        this.display = display;
        this.active = active;
        this.cooldowns = new int[]{c1, c2, c3};
        this.text = new String[]{t1, t2, t3};
    }

    public int cooldownTicks(int stage) {
        return cooldowns[Math.max(1, Math.min(3, stage)) - 1] * 20;
    }

    public String stageText(int stage) {
        return text[Math.max(1, Math.min(3, stage)) - 1];
    }

    public Power next() {
        Power[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public static Power byId(String id) {
        for (Power p : values()) {
            if (p.id.equalsIgnoreCase(id)) return p;
        }
        return null;
    }
}
