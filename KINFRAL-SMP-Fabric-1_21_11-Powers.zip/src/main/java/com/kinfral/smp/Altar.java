package com.kinfral.smp;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * The altar is built from vanilla blocks. Its core is an Enchanting Table sitting
 * on Crying Obsidian - that combo is what makes a table an altar, so no extra
 * saving is needed. Right-click it to buy the next stage of the selected power
 * (valuables are taken from your inventory). Sneak + right-click cycles the selected power.
 */
public final class Altar {
    private Altar() {}

    public static boolean isCore(World world, BlockPos pos) {
        return world.getBlockState(pos).isOf(Blocks.ENCHANTING_TABLE)
                && world.getBlockState(pos.down()).isOf(Blocks.CRYING_OBSIDIAN);
    }

    /** /altar : builds an altar where you are looking (or in front of you). */
    public static void summon(ServerPlayerEntity p) {
        ServerWorld w = Abilities.w(p);
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0F);
        BlockHitResult hit = w.raycast(new RaycastContext(eye, eye.add(look.multiply(8)),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));

        BlockPos c;
        if (hit.getType() == HitResult.Type.BLOCK) {
            c = hit.getBlockPos().up();
        } else {
            c = p.getBlockPos().offset(p.getHorizontalFacing(), 4);
        }
        // keep the 5x5 platform from swallowing the player
        double dx = c.getX() + 0.5 - p.getX();
        double dz = c.getZ() + 0.5 - p.getZ();
        if (Math.hypot(dx, dz) < 3.6) {
            c = c.offset(p.getHorizontalFacing(), 4);
        }

        build(w, c);
        p.sendMessage(Text.literal("§6[Altar] §fThe altar rises. Right-click the enchanting table to unlock powers."), false);
        p.sendMessage(Text.literal("§7Sneak + right-click it to switch power. Valuables are taken from your inventory."), false);
        show(p, Stages.selected(p));
    }

    private static void build(ServerWorld w, BlockPos c) {
        // clear space
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = 1; dy <= 4; dy++) {
                    w.setBlockState(c.add(dx, dy, dz), Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                }
            }
        }
        // floor
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                Block b;
                if (dx == 0 && dz == 0) b = Blocks.CRYING_OBSIDIAN;
                else if (Math.abs(dx) <= 1 && Math.abs(dz) <= 1) b = Blocks.GILDED_BLACKSTONE;
                else b = Blocks.POLISHED_BLACKSTONE_BRICKS;
                w.setBlockState(c.add(dx, 0, dz), b.getDefaultState(), Block.NOTIFY_ALL);
            }
        }
        // the altar itself
        w.setBlockState(c.up(), Blocks.ENCHANTING_TABLE.getDefaultState(), Block.NOTIFY_ALL);
        // corner pillars with soul lanterns
        for (int sx = -2; sx <= 2; sx += 4) {
            for (int sz = -2; sz <= 2; sz += 4) {
                w.setBlockState(c.add(sx, 1, sz), Blocks.CHISELED_POLISHED_BLACKSTONE.getDefaultState(), Block.NOTIFY_ALL);
                w.setBlockState(c.add(sx, 2, sz), Blocks.CHISELED_POLISHED_BLACKSTONE.getDefaultState(), Block.NOTIFY_ALL);
                w.setBlockState(c.add(sx, 3, sz), Blocks.SOUL_LANTERN.getDefaultState(), Block.NOTIFY_ALL);
            }
        }
        // effects
        LightningEntity bolt = new LightningEntity(EntityType.LIGHTNING_BOLT, w);
        bolt.setPosition(c.getX() + 0.5, c.getY() + 1, c.getZ() + 0.5);
        bolt.setCosmetic(true);
        w.spawnEntity(bolt);
        w.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, c.getX() + 0.5, c.getY() + 1.2, c.getZ() + 0.5,
                60, 1.5, 0.8, 1.5, 0.02);
    }

    /** Right-click on the altar core. */
    public static ActionResult use(ServerPlayerEntity p) {
        Power sel = Stages.selected(p);

        if (p.isSneaking()) {
            Power n = sel.next();
            Stages.select(p, n);
            show(p, n);
            return ActionResult.SUCCESS;
        }

        int st = Stages.get(p, sel);
        if (st >= 3) {
            p.sendMessage(Text.literal("§a" + sel.display + " is already at max stage. Sneak + right-click to pick another power."), false);
            return ActionResult.SUCCESS;
        }

        int next = st + 1;
        if (!Stages.canPay(p, next)) {
            int have = Stages.count(p, Stages.costItem(next));
            p.sendMessage(Text.literal("§cThe altar wants §e" + Stages.costText(next)
                    + "§c for " + sel.display + " stage " + next + ". You have " + have + "."), false);
            return ActionResult.SUCCESS;
        }

        Stages.pay(p, next);
        Stages.set(p, sel, next);

        ServerWorld w = Abilities.w(p);
        w.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 1, p.getZ(), 40, 0.6, 0.8, 0.6, 0.05);
        p.sendMessage(Text.literal("§6[Altar] §a" + sel.display + " reached stage " + next + "! §f" + sel.stageText(next)), false);
        if (sel.active) {
            p.sendMessage(Text.literal("§7Use it with the Power Wand (/powers wand)."), false);
        }
        return ActionResult.SUCCESS;
    }

    public static void show(ServerPlayerEntity p, Power pw) {
        int st = Stages.get(p, pw);
        String line = "§6" + pw.display + " §7[" + st + "/3] ";
        if (st < 3) {
            line += "§fNext: " + pw.stageText(st + 1) + " §8| costs §e" + Stages.costText(st + 1);
        } else {
            line += "§aMAX";
        }
        p.sendMessage(Text.literal(line), false);
    }
}
